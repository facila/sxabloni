# sxabloni_template.py version 1.00 Septembre 2026 par Thierry Le Gall

import re

def templates(struct,directory,template,value):
    if template not in struct:
       template_exec(struct,directory,template,value)
       return

    struct = struct[template]
    if isinstance(struct,dict):
       if value != "":
          if value.isdecimal(): value = int(value)
          if value in struct:
             template_exec(struct[value],directory,template,value)
       else:
          for value in struct:
              template_exec(struct[value],directory,template,value)
    elif isinstance(struct,list):
       if value != "":
          if value.isdecimal() and int(value) < len(struct):
             print("!")
             template_exec(struct[int(value)],directory,template,value)
       else:
          print("!")
          for value in struct:
              template_exec(value,directory,template,"")
    else:
       template_exec(struct,directory,template,"")

# Lecture et exécution du fichier template
def template_exec(struct,directory,template,value):
    file = directory/template
    if not file.is_file():
       print("!\n! fichier inexistant :",file)
       return

    # struct_new : reformatage de struct pour le template
    struct_new = {}
    if isinstance(struct,dict):
       if value : struct_new[template] = value
       if struct: struct_new.update(struct)
    else:
       struct_new[template] = struct

    with open(file, "r", encoding="utf-8") as f:
         for line in f:
             if line.startswith(">>"): break
             if line.startswith("##"): continue
             # autre template (( template ))
             if match := re.search(r"\(\(\s*(.*?)\s*\)\)",line):
                template = match.group(1)
                templates(struct_new,directory,template,"")
             else:
                template_line(struct_new,line)

# Remplace ou supprime un élément dans une ligne.
def template_line_replace(line_ref,test,value):
    line = line_ref[0]
    if value:
        line = line.replace(test,value)
    else:
        line = line.replace(" " + test,"")
        line = line.replace(test + " ","")
    line_ref[0] = line

# Traite une ligne de template
def template_line(struct,line):
    # liste [[ variable ]]
    if match := re.search(r"(\[\[\s*(.*?)\s*\]\])",line):
       test = match.group(1)
       var  = match.group(2)
       if list := struct.get(var):
          for value in list:
              result = line.replace(test,str(value))
              print(result,end="")
       return

    # dictionnaire {{ variable }}
    if match := re.search(r"(\{\{\s*(.*?)\s*\}\})",line):
       test  = match.group(1)
       var   = match.group(2)
       value = struct.get(var)
       if value:
          for dict in value:
              result = line.replace(test + " ","")
              for key in dict:
                  struct[key] = dict[key]
              template_line(struct,result)
       return

    # variable << variable >>
    while match := re.search(r"(<<\s*(.*?)\s*>>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = struct.get(var)
        if value: line = line.replace(test,str(value))
        else: return

    # option <O ... <o ... o> ... O>
    while match := re.search(r"(<O\s*(.*?(<o\s*(.*?)\s*o>).*?)\s*O>)",line):
        test  = match.group(1)
        var   = match.group(2)
        test1 = match.group(3)
        var1  = match.group(4)
        value = struct.get(var1)
        ref   = [line]
        if value:
           template_line_replace(ref,test,var)
           template_line_replace(ref,test1,str(value))
        else: template_line_replace(ref,test,"")
        line = ref[0]

    # option <o ... o>
    while match := re.search(r"(<o\s*(.*?)\s*o>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = struct.get(var)
        ref   = [line]
        template_line_replace(ref,test,str(value) if value else "")
        line = ref[0]

    # booléens <Bi ... <b ... b> ... B>
    while match := re.search(r"(<B(.)\s*(.*?(<b\s*(.*?)\s*b>).*?)\s*B>)",line):
        test  = match.group(1)
        i     = match.group(2)
        var   = match.group(3)
        test1 = match.group(4)
        var1  = match.group(5)
        value = struct.get(var1)
        if value is None or value == "undef":
           if i != "0": return # ligne pas affichée
        value = str(value)
        if i == "0" and value in ("False","false","0",""): var = test1 ; var1 = ""
        if i == "1" and value in ("False","false","0",""): var = test1
        if i == "2" and value in ("True" ,"true" ,"1"   ): var = test1
        if i == "3" and value in ("False","false","0",""): var = test1
        if i == "4" and value in ("True" ,"true" ,"1"   ): var = test1
        if i == "3" or i == "4" : var1 = ""
        ref = [line]
        template_line_replace(ref,test ,var)
        template_line_replace(ref,test1,var1)
        line = ref[0]

    # booleen <b ... b>
    while match := re.search(r"(<b\s*(.*?)\s*b>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = struct.get(var)
        if not value or str(value) in ("False","false","0",""):
           var = ""
        ref = [line]
        template_line_replace(ref,test,var)
        line = ref[0]

    # affichage du resultat
    print(line,end="")
