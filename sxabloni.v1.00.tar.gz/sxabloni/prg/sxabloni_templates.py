# sxabloni_template.py version 1.00 Septembre 2026 par Thierry Le Gall

import re

def templates(data,directory,template,value):
    if template not in data:
       template_exec(data,directory,template,value)
       return

    data = data[template]
    if isinstance(data,dict):
       if value != "":
          if value.isdecimal(): value = int(value)
          if value in data:
             template_exec(data[value],directory,template,value)
       else:
          for value in data:
              template_exec(data[value],directory,template,value)
    elif isinstance(data,list):
       if value != "":
          if value.isdecimal() and int(value) < len(data):
             print("!")
             template_exec(data[int(value)],directory,template,value)
       else:
          print("!")
          for value in data:
              template_exec(value,directory,template,"")
    else:
       template_exec(data,directory,template,"")

# Lecture et exécution du fichier template
def template_exec(data,directory,template,value):
    file = directory/template
    if not file.is_file():
       print("!\n! fichier inexistant :",file)
       return

    # data_new : reformatage de data pour le template
    data_new = {}
    if isinstance(data,dict):
       if value: data_new[template] = value
       if data : data_new.update(data)
    else:
       data_new[template] = data

    with open(file, "r", encoding="utf-8") as f:
         for line in f:
             if line.startswith(">>"): break
             if line.startswith("##"): continue
             # autre template (( template ))
             if match := re.search(r"\(\(\s*(.*?)\s*\)\)",line):
                template = match.group(1)
                templates(data_new,directory,template,"")
             else:
                template_line(data_new,line)

# Remplace ou supprime un élément dans une ligne.
def template_line_replace(line_ref,test,value):
    line = line_ref[0]
    if value:
        line = line.replace(test,value)
    else:
        line = line.replace(" " + test,"")
        line = line.replace(test + " ","")
    line_ref[0] = line

# Traite une ligne de template
def template_line(data,line):
    # liste [[ variable ]]
    if match := re.search(r"(\[\[\s*(.*?)\s*\]\])",line):
       test = match.group(1)
       var  = match.group(2)
       if list := data.get(var):
          for value in list:
              result = line.replace(test,str(value))
              print(result,end="")
       return

    # dictionnaire {{ variable }}
    if match := re.search(r"(\{\{\s*(.*?)\s*\}\})",line):
       test  = match.group(1)
       var   = match.group(2)
       value = data.get(var)
       if value:
          for dict in value:
              result = line.replace(test + " ","")
              for key in dict:
                  data[key] = dict[key]
              template_line(data,result)
       return

    # variable << variable >>
    while match := re.search(r"(<<\s*(.*?)\s*>>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = data.get(var)
        if value: line = line.replace(test,str(value))
        else: return

    # option <O ... <o ... o> ... O>
    while match := re.search(r"(<O\s*(.*?(<o\s*(.*?)\s*o>).*?)\s*O>)",line):
        test  = match.group(1)
        var   = match.group(2)
        test1 = match.group(3)
        var1  = match.group(4)
        value = data.get(var1)
        ref   = [line]
        if value:
           template_line_replace(ref,test,var)
           template_line_replace(ref,test1,str(value))
        else: template_line_replace(ref,test,"")
        line = ref[0]

    # option <o ... o>
    while match := re.search(r"(<o\s*(.*?)\s*o>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = data.get(var)
        ref   = [line]
        template_line_replace(ref,test,str(value) if value else "")
        line = ref[0]

    # booléens <Bi ... <b ... b> ... B>
    while match := re.search(r"(<B(.)\s*(.*?(<b\s*(.*?)\s*b>).*?)\s*B>)",line):
        test  = match.group(1)
        i     = match.group(2)
        var   = match.group(3)
        test1 = match.group(4)
        var1  = match.group(5)
        value = data.get(var1)
        if value is None or value == "undef":
           if i != "0": return # ligne pas affichée
        value = str(value)
        if i == "0" and value in ("False","false","0",""): var = test1 ; var1 = ""
        if i == "1" and value in ("False","false","0",""): var = test1
        if i == "2" and value in ("True" ,"true" ,"1"   ): var = test1
        if i == "3" and value in ("False","false","0",""): var = test1
        if i == "4" and value in ("True" ,"true" ,"1"   ): var = test1
        if i == "3" or i == "4" : var1 = ""
        ref = [line]
        template_line_replace(ref,test ,var)
        template_line_replace(ref,test1,var1)
        line = ref[0]

    # booleen <b ... b>
    while match := re.search(r"(<b\s*(.*?)\s*b>)",line):
        test  = match.group(1)
        var   = match.group(2)
        value = data.get(var)
        if not value or str(value) in ("False","false","0",""):
           var = ""
        ref = [line]
        template_line_replace(ref,test,var)
        line = ref[0]

    # affichage du resultat
    print(line,end="")
