#!/usr/bin/env python3

# sxabloni.py version 1.00 Septembre 2026 par Thierry Le Gall

# syntaxe  : faire sxabloni.py -h
# template : faire sxabloni.py -e 

# Localisation du répertoire de l'application
from pathlib import Path
directory = Path(__file__).resolve().parent.parent

file = directory/"prg/sxabloni.hlp"
with file.open("r", encoding="utf-8") as f:
     epilog = f.read()

# Arguments
import argparse
parser = argparse.ArgumentParser(epilog=epilog,formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument("model"   ,nargs="?")
parser.add_argument("template",nargs="?")
parser.add_argument("value"   ,nargs="?",default="",help="optional")
parser.add_argument("-t",help="format des templates"  ,action="store_true")
parser.add_argument("-f",help="affichage des fichiers",action="store_true")
parser.add_argument("-y",help="fichier yaml")
parser.add_argument("-d",help="fichier dsl")
args = parser.parse_args()

def is_file(file):
    if not file.is_file():
       print("! fichier inexistant :",file)
       exit(0)

def print_file(file):
    file = directory/file
    is_file(file)
    print("---------")
    print("fichier :",file)
    print("---------")
    with file.open("r", encoding="utf-8") as f:
         print(f.read(),end="")

if args.t:
   print_file("prg/sxabloni_templates.hlp")
   exit(0)

model    = args.model
template = args.template

if not model:
   exit(0)

if args.f:
   if   template : print_file(f"model/{model}/template/{template}")
   elif args.y   : print_file(f"model/{model}/yaml/{args.y}")
   elif args.d   : print_file(f"model/{model}/dsl/{args.d}")
   else          : print_file(f"module/{model}.py")
   exit(0)

# création de struct
struct = ""
if args.y:
   file = directory/"model"/model/"yaml"/args.y
   is_file(file)
   import yaml
   with file.open("r", encoding="utf-8") as f:
        struct = yaml.safe_load(f)

elif args.d:
   file = directory/"model"/model/"dsl"/args.d
   is_file(file)
   is_file(directory/"module"/f"{model}.py")
   # ajout de directory dans le path pour pouvoir accéder au module
   import sys
   sys.path.insert(0,str(directory))
   # ajout des fonctions du module dans globals pour pouvoir executer une fonction variable
   import importlib
   globals().update(vars(importlib.import_module(f"module.{model}")))
   import shlex
   with file.open("r", encoding="utf-8") as f:
        for line in f:
            list = shlex.split(line.strip())
            if not list: continue
            if list[0] in globals():
               fonction = globals()[list[0]]
               fonction(struct,*list[1:])
            else:
               print("! fonction inexistante :",list[0])
else:
   exit(0)

# affichage de struct
if struct and not template:
   from pprint import pprint 
   pprint(struct)
   exit(0)

# Exécution des templates
from sxabloni_templates import *
templates(struct,directory/"model"/model/"template",template,args.value)
