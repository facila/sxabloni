# data_cisco.py version 1.00 Septembre 2026 par Thierry Le Gall

# l'ordre dans data défini l'ordre d'exécution des templates
data = {
     "hostname"     : "" ,
     "vrfs"         : {} ,
     "vlans"        : {} ,
     "interfaces"   : {} ,
     "static_routes": [] }

def var_val(data,var,val):
    data[var] = val

def vrfs(data,vrf,description,rd):
    data["vrfs"].setdefault(vrf,{})
    data["vrfs"][vrf]["description"] = description
    data["vrfs"][vrf]["rd"         ] = rd

def vlans(data,vlan,name):
    vlan = int(vlan)
    data["vlans"].setdefault(vlan,{})
    data["vlans"][vlan]["name"] = name

def interfaces(data,interface,shutdown,switchport,description):
    shutdown   = int(shutdown)
    switchport = int(switchport)
    data["interfaces"].setdefault(interface,{})
    data["interfaces"][interface]["shutdown"   ] = shutdown
    data["interfaces"][interface]["switchport" ] = switchport
    data["interfaces"][interface]["description"] = description

def addresses(data,interface,ip,mask,secondary):
    secondary = int(secondary)
    data["interfaces"].setdefault(interface,{})
    data["interfaces"][interface].setdefault("addresses",[])
    data["interfaces"][interface]["addresses"].append({"ip":ip,"mask":mask,"secondary":secondary})

def helpers(data,interface,ip):
    data["interfaces"].setdefault(interface,{})
    data["interfaces"][interface].setdefault("helpers",[])
    data["interfaces"][interface]["helpers"].append(ip)

def standbys(data,interface,standby,ip,preempt,priority):
    standby  = int(standby)
    preempt  = int(preempt)
    priority = int(priority)
    data["interfaces"].setdefault(interface,{})
    data["interfaces"][interface].setdefault("standbys",{})
    data["interfaces"][interface]["standbys"].setdefault(standby,{})
    data["interfaces"][interface]["standbys"][standby]["virtual_ip"] = ip
    data["interfaces"][interface]["standbys"][standby]["preempt"]    = preempt
    data["interfaces"][interface]["standbys"][standby]["priority"]   = priority

def static_routes(data,vrf,destination,mask,next_hop):
    data["static_routes"].append({"vrf":vrf,"destination":destination,"mask":mask,"next_hop":next_hop})
