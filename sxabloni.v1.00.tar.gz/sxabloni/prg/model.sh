#!/bin/bash

printf "nom du nouveau modéle : "
read MODEL
[ "$MODEL" = '' ] && exit

cd $(dirname ${BASH_SOURCE[0]})
cd ..

mkdir model/$MODEL
mkdir model/$MODEL/dsl
mkdir model/$MODEL/template
mkdir model/$MODEL/yaml

cp -p  module/new.py module/$MODEL.py
sed -i "s/new/$MODEL/" module/$MODEL.py
