# new.py version 1.00

# l'ordre dans struct défini l'ordre d'exécution des templates
struct = {
     "var"  : "" ,
     "dict" : {} ,
     "list" : [] }

def var_val(struct,var,val):
    struct[var] = val
