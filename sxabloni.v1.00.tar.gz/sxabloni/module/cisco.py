# struct_cisco.py version 1.00 Septembre 2026 par Thierry Le Gall

# l'ordre dans struct défini l'ordre d'exécution des templates
struct = {
     "hostname"     : "" ,
     "vrfs"         : {} ,
     "vlans"        : {} ,
     "interfaces"   : {} ,
     "static_routes": [] }

def var_val(struct,var,val):
    struct[var] = val

def vrfs(struct,vrf,description,rd):
    struct["vrfs"].setdefault(vrf,{})
    struct["vrfs"][vrf]["description"] = description
    struct["vrfs"][vrf]["rd"         ] = rd

def vlans(struct,vlan,name):
    vlan = int(vlan)
    struct["vlans"].setdefault(vlan,{})
    struct["vlans"][vlan]["name"] = name

def interfaces(struct,interface,shutdown,switchport,description):
    shutdown   = int(shutdown)
    switchport = int(switchport)
    struct["interfaces"].setdefault(interface,{})
    struct["interfaces"][interface]["shutdown"   ] = shutdown
    struct["interfaces"][interface]["switchport" ] = switchport
    struct["interfaces"][interface]["description"] = description

def addresses(struct,interface,ip,mask,secondary):
    secondary = int(secondary)
    struct["interfaces"].setdefault(interface,{})
    struct["interfaces"][interface].setdefault("addresses",[])
    struct["interfaces"][interface]["addresses"].append({"ip":ip,"mask":mask,"secondary":secondary})

def helpers(struct,interface,ip):
    struct["interfaces"].setdefault(interface,{})
    struct["interfaces"][interface].setdefault("helpers",[])
    struct["interfaces"][interface]["helpers"].append(ip)

def standbys(struct,interface,standby,ip,preempt,priority):
    standby  = int(standby)
    preempt  = int(preempt)
    priority = int(priority)
    struct["interfaces"].setdefault(interface,{})
    struct["interfaces"][interface].setdefault("standbys",{})
    struct["interfaces"][interface]["standbys"].setdefault(standby,{})
    struct["interfaces"][interface]["standbys"][standby]["virtual_ip"] = ip
    struct["interfaces"][interface]["standbys"][standby]["preempt"   ] = preempt
    struct["interfaces"][interface]["standbys"][standby]["priority"  ] = priority

def static_routes(struct,vrf,destination,mask,next_hop):
    struct["static_routes"].append({"vrf":vrf,"destination":destination,"mask":mask,"next_hop":next_hop})
